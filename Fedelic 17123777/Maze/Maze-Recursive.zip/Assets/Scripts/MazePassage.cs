﻿using UnityEngine;

public class MazePassage : MazeCellEdge {}