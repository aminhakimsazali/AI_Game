package examples.StarterGhostComm;

import pacman.game.Constants;

/**
 * Created by Piers on 11/11/2015.
 */
public class Blinky extends POCommGhost {


    public Blinky() {
        super(Constants.GHOST.BLINKY, 50);
    }

}
