package examples.StarterPacMan;

import pacman.Executor;
import pacman.controllers.PacmanController;
import pacman.game.Constants;
import pacman.game.Constants.DM;
import pacman.game.Constants.MOVE;
import pacman.game.Constants.GHOST;
import pacman.game.Game;
import pacman.game.GameView;

import java.awt.Color;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;


public class PacManController extends PacmanController{
    private static final Random RANDOM = new Random(); 
	private Game game;
	private int pacmanCurrentNodeIndex;
	MOVE pacmanLastMoveMade; 
        int searchDepth = 50;
	private List paths = new ArrayList<>();
         
        private int maxScore;
        private MOVE[] bestPath;
        private GHOST[] ghosts = GHOST.values();
        private int ghostNodes[];
        private int powerPills[];
    
    
    @Override
    public MOVE getMove(Game game, long timeDue) {
       this.game = game;
       pacmanCurrentNodeIndex = game.getPacmanCurrentNodeIndex();
       int currentNode = game.getPacmanCurrentNodeIndex();
       findPath(currentNode);
       
       //game.getPossibleMoves(moveNode)
       //game.getNeighbour();
       //game.getPacmanCurrentNodeIndex()
       //game.getGhostCurrentNodeIndex
       //game.getPillIndex(currentNode);
       //game.getPowerPillIndex(currentNode);	
       //game.getActivePowerPillsIndices()
       //game.isGhostEdible(GHOST.SUE)
       //game.getGhostEdibleTime(GHOST.SUE)
       
        MOVE bestPathMove = bestPath[0];
        System.out.println(maxScore);
       return bestPathMove;
    }
    

    private void findPath(int current){
        
        ghostNodes = new int[ghosts.length];
        for(int x = 0 ; x < ghosts.length ; x++){
            ghostNodes[x] = game.getGhostCurrentNodeIndex(ghosts[x]);

        }
 
        powerPills = game.getPowerPillIndices();
        maxScore = -1;
        
        MOVE[] possibleMoves = game.getPossibleMoves(current);
        
        for(int x = 0 ; x < possibleMoves.length ; x++){
            int score = 0;
            int depth = 0;
            int nextNode = game.getNeighbour(current, possibleMoves[x]);
            
            if(game.getPillIndex(nextNode)!=-1){
                score+=5;
            }
            if(game.getPowerPillIndex(nextNode)!=-1){
                score+=150;
            }
            
            
            double totalDistToGhost1 = 0;
            double totalDistToGhost2 = 0;

                for(int y = 0 ; y < ghosts.length ; y++){
                    double d1 = game.getDistance(pacmanCurrentNodeIndex, ghostNodes[y], DM.PATH);
                    totalDistToGhost1 += d1;
                    
                    if(game.isGhostEdible(ghosts[y])){
                        double d2 = game.getDistance(current, ghostNodes[y], DM.PATH);
                        score += (int) 15.0*(1.0-d2/d1);
                    }
                    else{
                        double d2 = game.getDistance(current, ghostNodes[y], DM.PATH);
                        if(game.getPowerPillIndex(nextNode)!=-1){
                            //score += (int) 1000*(1.0-(d2+game.getDistance(current,nextNode,DM.PATH))/(d1*1.5));
                        }
                        else{
                            double f = d2/d1;
                            if(f > 0.5)
                                score-=10;
                            score -= (int) 18.0*(1.0-f);
                        }
                    }
                }
                
            
            
            MOVE[] movesMade = new MOVE[searchDepth];
            movesMade[depth] = possibleMoves[x];
            if(possibleMoves[x] == game.getPacmanLastMoveMade())
                score-=20;
            findPath(nextNode, score, movesMade, depth+1 );
        }
        
    }
    
    private void findPath(int current,int score, MOVE[] moves, int depth){
        
        if(depth<searchDepth){
            MOVE[] possibleMoves = game.getPossibleMoves(current,moves[depth-1]);

            for(int x = 0 ; x < possibleMoves.length ; x++){
                
                int nextNode = game.getNeighbour(current, possibleMoves[x]);    
                if(game.getPillIndex(nextNode)!=-1){
                    score+=10;
                }
                if(game.getPowerPillIndex(nextNode)!=-1){
                    score+=150;
                }
                
                double totalDistToGhost1 = 0;
                double totalDistToGhost2 = 0;

                for(int y = 0 ; y < ghosts.length ; y++){
                    double d1 = game.getDistance(pacmanCurrentNodeIndex, ghostNodes[y], DM.PATH);
                    totalDistToGhost1 += d1;
                    
                    if(game.isGhostEdible(ghosts[y])){
                        double d2 = game.getDistance(current, ghostNodes[y], DM.PATH);
                        score += (int) 15.0*(1.0-d2/d1);
                    }
                    else{
                        double d2 = game.getDistance(current, ghostNodes[y], DM.PATH);
                        if(game.getPowerPillIndex(nextNode)!=-1){
                            //score += (int) 1000*(1.0-(d2+game.getDistance(current,nextNode,DM.PATH))/(d1*1.5));
                        }
                        else{
                            double f = d2/d1;
                            //if(d2/d1 > 0.5)
                            //    score-=10;
                            score -= (int) 30.0*(1.0-f);
                        }
                    }
                }
                

                moves[depth] = possibleMoves[x];
                findPath(game.getNeighbour(current, possibleMoves[x]), score, moves, depth+1 );

            }
        }
        else{
            if(maxScore==-1){
                maxScore = score;
                bestPath = moves;
            }
            else{
                if(score > maxScore){
                    maxScore = score;
                    bestPath = moves;
                }
            
            }
        
        }
    
    }
    
    
}
