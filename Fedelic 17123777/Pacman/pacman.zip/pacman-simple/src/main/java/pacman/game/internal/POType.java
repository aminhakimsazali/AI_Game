package pacman.game.internal;

/**
 * Created by Piers on 17/08/2016.
 */
public enum POType {
    LOS,
    FF_LOS,
    RADIUS
}
