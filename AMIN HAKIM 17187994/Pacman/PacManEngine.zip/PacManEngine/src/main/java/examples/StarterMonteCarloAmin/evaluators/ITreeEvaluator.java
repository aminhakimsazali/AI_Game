package examples.StarterMonteCarloAmin.evaluators;

import examples.StarterMonteCarloAmin.MonteCarloTree;

public interface ITreeEvaluator {
	void evaluateTree(MonteCarloTree simulator);
}
