namespace UnityEngine.Advertisements.Editor {
    public static class SkAdNetworkFileExtension {
        public const string XML = "xml";
        public const string JSON = "json";
        public const string NONE = "";
    }
}
