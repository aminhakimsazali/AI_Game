#import "UnityAdsExtendedDelegate.h"

#warning "UnityAdsExtended.h" is deprecated and will be removed in the next major version please move to using "UnityAdsExtendedDelegate.h"
